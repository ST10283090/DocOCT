﻿using Azure;
using Azure.Data.Tables;
using _10Days_OUT_CLDV.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Linq; 

public class TransactionsController : Controller
{
    private readonly HttpClient _httpClient;
    private readonly string _azureFunctionUrl = "https://mhkat.azurewebsites.net/api/RegisterTransaction?";
    private readonly TableStorageService _tableStorageService;

    public TransactionsController(HttpClient httpClient, TableStorageService tableStorageService)
    {
        _httpClient = httpClient;
        _tableStorageService = tableStorageService;
    }

    public async Task<IActionResult> Index()
    {
        var transactions = await _tableStorageService.GetAllTransactionsAsync();
        return View(transactions);
    }

    public async Task<IActionResult> Register()
    {
        var customers = await _tableStorageService.GetAllCustomersAsync();
        var products = await _tableStorageService.GetAllProductsAsync();

        if (customers == null || !customers.Any())
        {
            ModelState.AddModelError("", "No customers found. Please add some first.");
            return View();
        }

        if (products == null || !products.Any())
        {
            ModelState.AddModelError("", "No products found. Please add at least one item first.");
            return View();
        }

        ViewData["Customers"] = customers;
        ViewData["Products"] = products;

        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Register(Transaction transaction)
    {
        if (ModelState.IsValid)
        {
            var json = JsonSerializer.Serialize(transaction);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            Console.WriteLine(json);

            var response = await _httpClient.PostAsync(_azureFunctionUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError("", "Error occurred while registering the transaction.");
            }
        }
        else
        {
            foreach (var error in ModelState)
            {
                Console.WriteLine($"Key: {error.Key}, Errors: {string.Join(", ", error.Value.Errors.Select(e => e.ErrorMessage))}");
            }
        }

        var customers = await _tableStorageService.GetAllCustomersAsync();
        var products = await _tableStorageService.GetAllProductsAsync();
        ViewData["Customers"] = customers;
        ViewData["Products"] = products;

        return View(transaction);
    }
}






