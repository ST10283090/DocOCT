﻿using _10Days_OUT_CLDV.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

public class CustomersController : Controller
{
    private readonly TableStorageService _tableStorageService;
    private readonly HttpClient _httpClient;

    public CustomersController(TableStorageService tableStorageService, HttpClient httpClient)
    {
        _tableStorageService = tableStorageService;
        _httpClient = httpClient;
    }

    public async Task<IActionResult> Index()
    {
        var customers = await _tableStorageService.GetAllCustomersAsync();
        return View(customers);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Create(Customer customer)
    {
        var customerData = new
        {
            Customer_Name = customer.Customer_Name,
            Customer_Email = customer.Customer_Email,
            Customer_Password = customer.Customer_Password 

        };

        var json = JsonConvert.SerializeObject(customerData);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var response = await _httpClient.PostAsync("https://mhkat.azurewebsites.net/api/AddCustomer", content);

        if (response.IsSuccessStatusCode)
        {
            return RedirectToAction("Index");
        }
        else
        {
            ModelState.AddModelError("", "Error adding customer");
            return View(customer);
        }
    }

    public async Task<IActionResult> Delete(string partitionKey, string rowKey)
    {
        await _tableStorageService.DeleteCustomerAsync(partitionKey, rowKey);
        return RedirectToAction("Index");
    }

    public async Task<IActionResult> Details(string partitionKey, string rowKey)
    {
        var customer = await _tableStorageService.GetCustomerAsync(partitionKey, rowKey);
        if (customer == null)
        {
            return NotFound();
        }
        return View(customer);
    }
}

