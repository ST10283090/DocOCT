﻿using _10Days_OUT_CLDV.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

public class FilesController : Controller
{
    private readonly AzureFileShareService _fileShareService;
    private readonly HttpClient _httpClient;

    public FilesController(AzureFileShareService fileShareService, HttpClient httpClient)
    {
        _fileShareService = fileShareService;
        _httpClient = httpClient;
    }

    public async Task<IActionResult> Index()
    {
        List<FileModel> files;
        try
        {
            files = await _fileShareService.ListFilesAsync("uploads");
        }
        catch (Exception ex)
        {
            ViewBag.Message = $"Failed to load files: {ex.Message}";
            files = new List<FileModel>();
        }

        return View(files);
    }

    [HttpPost]
    public async Task<IActionResult> Upload(IFormFile file)
    {
        if (file == null || file.Length == 0)
        {
            ModelState.AddModelError("file", "Please select a file to upload.");
            return await Index();
        }

        try
        {
            using (var stream = file.OpenReadStream())
            {
                string url = "https://mhkat.azurewebsites.net/api/TombstoneFileDrive?"; 
                using var content = new MultipartFormDataContent();
                content.Add(new StreamContent(stream), "file", file.FileName);

                var response = await _httpClient.PostAsync(url, content);
                response.EnsureSuccessStatusCode();

                TempData["Message"] = $"File '{file.FileName}' uploaded successfully!";
            }
        }
        catch (Exception ex)
        {
            TempData["Message"] = $"File upload failed: {ex.Message}";
        }

        return RedirectToAction("Index");
    }

    [HttpGet]
    public async Task<IActionResult> DownloadFile(string fileName)
    {
        if (string.IsNullOrEmpty(fileName))
        {
            return BadRequest("File name cannot be empty.");
        }

        try
        {
            var fileStream = await _fileShareService.DownloadFileAsync("uploads", fileName);

            if (fileStream == null)
            {
                return NotFound($"File '{fileName}' not found.");
            }

            return File(fileStream, "application/octet-stream", fileName);
        }
        catch (Exception ex)
        {
            return BadRequest($"Error downloading file: {ex.Message}");
        }
    }
}



