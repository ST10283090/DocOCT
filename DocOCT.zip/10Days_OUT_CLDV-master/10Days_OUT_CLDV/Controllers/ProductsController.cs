﻿using _10Days_OUT_CLDV.Services;
using _10Days_OUT_CLDV.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.IO;

public class ProductsController : Controller
{
    private readonly TableStorageService _tableStorageService;
    private readonly BlobService _blobStorageService;
    private readonly HttpClient _httpClient;

    public ProductsController(TableStorageService tableStorageService, BlobService blobStorageService, HttpClient httpClient)
    {
        _tableStorageService = tableStorageService;
        _blobStorageService = blobStorageService;
        _httpClient = httpClient;
    }

    [HttpGet]
    public IActionResult AddProduct()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> AddProduct(Product product, IFormFile file)
    {
        if (file != null)
        {
            using var memoryStream = new MemoryStream();
            await file.CopyToAsync(memoryStream);
            memoryStream.Position = 0;

            string imageUrl = await _blobStorageService.UploadBlobAsync(memoryStream, file.FileName);
            product.ImageUrl = imageUrl;
        }

        if (ModelState.IsValid)
        {
            product.PartitionKey = "ProductsPartition";
            product.RowKey = Guid.NewGuid().ToString();
            await _tableStorageService.AddProductAsync(product);
            return RedirectToAction("Index");
        }

        return View(product);
    }

    [HttpPost]
    public async Task<IActionResult> DeleteProduct(string partitionKey, string rowKey, Product product)
    {
        await _tableStorageService.DeleteProductAsync(partitionKey, rowKey);
        return RedirectToAction("Index");
    }

    public async Task<IActionResult> Index()
    {
        var products = await _tableStorageService.GetAllProductsAsync();
        return View(products);
    }
}






