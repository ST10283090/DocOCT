﻿using Azure.Storage.Blobs;
using System;
using System.IO;
using System.Threading.Tasks;

namespace _10Days_OUT_CLDV.Services 
{
    public class BlobService
    {
        private readonly BlobContainerClient _blobContainerClient;

        public BlobService(string connectionString, string containerName)
        {
            var blobServiceClient = new BlobServiceClient(connectionString);
            _blobContainerClient = blobServiceClient.GetBlobContainerClient(containerName);
            _blobContainerClient.CreateIfNotExists();
        }

        public async Task<string> UploadBlobAsync(Stream fileStream, string fileName)
        {
            var blobClient = _blobContainerClient.GetBlobClient(fileName);
            await blobClient.UploadAsync(fileStream, overwrite: true);
            return blobClient.Uri.ToString();
        }

        public async Task DeleteBlobAsync(string fileName)
        {
            var blobClient = _blobContainerClient.GetBlobClient(fileName);
            await blobClient.DeleteIfExistsAsync();
        }
    }
}



